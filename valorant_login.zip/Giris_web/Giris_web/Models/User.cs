﻿using System.ComponentModel.DataAnnotations;

namespace Giris_web.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Kullanıcı adı gerekli.")]
        [StringLength(50)]
        public string Username { get; set; }

        [Required(ErrorMessage = "Şifre gerekli.")]
        [StringLength(50)]
        public string Password { get; set; }
    }
}
