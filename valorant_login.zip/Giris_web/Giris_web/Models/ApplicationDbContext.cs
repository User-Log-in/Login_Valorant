﻿using System.Data.Entity;

namespace Giris_web.Models
{
    public class ApplicationDbContext : DbContext
    {
        public DbSet<User> Users { get; set; }

        public ApplicationDbContext() : base("DefaultConnection")
        {
        }
    }

}
