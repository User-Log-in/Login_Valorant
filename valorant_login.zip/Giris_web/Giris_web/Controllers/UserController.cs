﻿using Giris_web.Models;
using Microsoft.AspNetCore.Mvc;

namespace Giris_web.Controllers
{
    public class UserController : Controller
    {
        private readonly ApplicationDbContext db = new ApplicationDbContext();

        // GET: User/Create
        public IActionResult Create()
        {
            return View(); // Bu, /Views/User/Create.cshtml'yi kullanır
        }

        // POST: User/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(User user)
        {
            if (ModelState.IsValid)
            {
                db.Users.Add(user);
                db.SaveChanges();
                return RedirectToAction("Index"); // Veritabanı işlemleri başarılıysa Index'e yönlendirir
            }
            return View(user);
        }

        // GET: User/Index
        public IActionResult Index()
        {
            var users = db.Users.ToList();
            return View(users); // Bu, /Views/User/Index.cshtml'yi kullanır
        }
    }
}
