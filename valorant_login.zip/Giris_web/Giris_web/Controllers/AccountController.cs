﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;

namespace Giris_web.Controllers
{
    public class AccountController : Controller
    {
        // Veritabanı bağlantı dizesi
        private readonly string connectionString = "Server=DESKTOP-O31D5GH\\SQLEXPRESS;Database=mydatabase;Integrated Security=True;";

        // GET: Register
        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }

        // POST: Register
        [HttpPost]
        public ActionResult Register(string username, string password)
        {
            if (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password))
            {
                // Veritabanına bağlanma ve kullanıcıyı kaydetme işlemi
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        // Bağlantıyı aç
                        connection.Open();

                        // SQL komutu: Kullanıcıyı 'users' tablosuna ekleme
                        string query = "INSERT INTO users (username, password) VALUES (@username, @password)";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            // Parametreleri ekle
                            command.Parameters.AddWithValue("@username", username);
                            command.Parameters.AddWithValue("@password", password); // Şifreyi direkt olarak kaydediyoruz (gerçek projelerde şifrelerin hashed olmasını öneririm)

                            // SQL komutunu çalıştır
                            int result = command.ExecuteNonQuery();

                            if (result > 0)
                            {
                                // Kayıt başarılı
                                TempData["SuccessMessage"] = "Registration successful!";
                                return RedirectToAction("Success");
                            }
                            else
                            {
                                // Kayıt başarısız
                                ViewBag.ErrorMessage = "Error in saving user data.";
                            }
                        }
                    }
                    catch (SqlException ex)
                    {
                        // Hata mesajı
                        ViewBag.ErrorMessage = "Database connection error: " + ex.Message;
                    }
                    finally
                    {
                        // Bağlantıyı kapatma
                        if (connection.State == System.Data.ConnectionState.Open)
                        {
                            connection.Close();
                        }
                    }
                }
            }
            else
            {
                // Boş alanlar varsa hata mesajı
                ViewBag.ErrorMessage = "Both fields are required!";
            }
            return RedirectToAction("Index"); // Veritabanı işlemleri başarılıysa Index'e yönlendirir
            // Hata varsa yeniden register view'ına dön
            
        }

        public ActionResult Success()
        {
            return View(); // Başarılı kayıt için ayrı bir View
        }
    }
}
